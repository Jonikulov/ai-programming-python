# gb-distributionsp package

The **gb-distributionsp** package includes Gaussian and Binomial distributions.

# Installation

`pip install gb-distributionsp`
